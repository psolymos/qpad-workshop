# Version 0.2-3, 2021-03-15

* Shiny app fixes to allow vocalization and movement related tau values.

# Version 0.2-2, 2021-01-17

* Added `sensitivity` argument to `bsims_detect`.
* Revised vignettes.

# Version 0.2-1, 2019-12-16 (CRAN)

* Replaced `\dontrun{}` with `\donttest{}` in Rd files.
* Added references to Rd files and `DESCRIPTION` with DOI.

# Version 0.2-0, 2019-12-09

* Added tutorial as vignette (#10).
* Added `run_app` to run Shiny apps.
* Added `estimate` method to fit simple models and estimate density.

# Version 0.1-3, 2019-09-18

* Incorporated feedback (GitHub issues #1-8).

# Version 0.1-2, 2019-07-02

* Shiny apps added to `/inst/shiny` folder.

# Version 0.1-1, 2019-06-24

* HER simulation fixed when `edge=0`.

# Version 0.1-0, 2019-06-21

* Initial functionality is stable.

# Version 0.0-1, 2019-05-15

* Initial functionality is added.
